<?php
App::uses('AppController', 'Controller');
/**
 * AlotmentTransfers Controller
 *
 * @property AlotmentTransfer $AlotmentTransfer
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class AlotmentTransfersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Alotment transfer List');
		$this->AlotmentTransfer->recursive = 2;
		$this->paginate = array('order' => array('AlotmentTransfer.id' => 'DESC'));
		$this->set('alotmentTransfers', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Alotment transfer Details');
		if (!$this->AlotmentTransfer->exists($id)) {
			throw new NotFoundException(__('Invalid alotment transfer'));
		}
		$options = array('conditions' => array('AlotmentTransfer.' . $this->AlotmentTransfer->primaryKey => $id));
		$this->set('alotmentTransfer', $this->AlotmentTransfer->find('first', $options));

		$alotment_id = $this->AlotmentTransfer->find('all',array('fields' => array('alotment_id'),'conditions' => array('AlotmentTransfer.id' => $id)));
		$alt_id = $alotment_id[0]['AlotmentTransfer']['alotment_id'];

		$alotments = $this->AlotmentTransfer->Alotment->find('all',array('conditions' => array('Alotment.id' => $alt_id)));
		$this->set(compact('alotments'));

	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Alotment transfer');
		if ($this->request->is('post')) {

			if(empty($this->request->data['AlotmentTransfer']['alotment_id']))
			{
				$this->Session->setFlash(__('The alotment transfer could not be saved. Please, try again.'), 'flash/error');
				$this->redirect(array('action' => 'index'));
			}
			$this->AlotmentTransfer->create();
			$this->request->data['AlotmentTransfer']['created_at'] = $this->current_datetime();
			$this->request->data['AlotmentTransfer']['user_id'] = $this->UserAuth->getUserId();			
			if ($this->AlotmentTransfer->save($this->request->data)) {
				$this->Session->setFlash(__('The alotment transfer has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The alotment transfer could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$alotments = $this->AlotmentTransfer->Alotment->find('list');
		$users = $this->AlotmentTransfer->User->find('list');
		$this->set(compact('alotments', 'users'));

		$this->loadModel('AlotmentType');
		$AlotmentType = $this->AlotmentType->find('list');

		$this->loadModel('PloatType');
		$PloatType = $this->PloatType->find('list');

		$this->set(compact('AlotmentType','PloatType'));

	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Alotment transfer');
		$this->AlotmentTransfer->id = $id;
		if (!$this->AlotmentTransfer->exists($id)) {
			throw new NotFoundException(__('Invalid alotment transfer'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['AlotmentTransfer']['user_id'] = $this->UserAuth->getUserId();
			$this->request->data['AlotmentTransfer']['updated_at'] = $this->current_datetime();

			if ($this->AlotmentTransfer->save($this->request->data)) {
				$this->Session->setFlash(__('The alotment transfer has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The alotment transfer could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('AlotmentTransfer.' . $this->AlotmentTransfer->primaryKey => $id));
			$this->request->data = $this->AlotmentTransfer->find('first', $options);
		}
		$alotment_id = $this->AlotmentTransfer->find('all',array('fields' => array('alotment_id'),'conditions' => array('AlotmentTransfer.id' => $id)));
		$alt_id = $alotment_id[0]['AlotmentTransfer']['alotment_id'];

		$alotments = $this->AlotmentTransfer->Alotment->find('all',array('conditions' => array('Alotment.id' => $alt_id)));

		$users = $this->AlotmentTransfer->User->find('list');
		$this->set(compact('alotments','users','alotment_id'));
			
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->AlotmentTransfer->id = $id;
		if (!$this->AlotmentTransfer->exists()) {
			throw new NotFoundException(__('Invalid alotment transfer'));
		}
		if ($this->AlotmentTransfer->delete()) {
			$this->Session->setFlash(__('Alotment transfer deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Alotment transfer was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}

	public function admin_get_call()
	{
		if($this->request->is('post'))
		{
			function input($data) {
			  $data = trim($data);
			  $data = stripslashes($data);
			  $data = htmlspecialchars($data);
			  
			  return $data;
			 }

			$alotent_type_id = input($this->request->data['alotent_type_id']);
			$ploat_type_id = input($this->request->data['ploat_type_id']);
			$plot_shop_no = input($this->request->data['plot_shop_no']);

			$this->loadModel('Alotment');
			$alotment = $this->Alotment->find('all',array('conditions' => array('Alotment.alotment_type_id' => $alotent_type_id, 'Alotment.ploat_type_id' => $ploat_type_id, 'Alotment.plot_shop_billboard_no' => $plot_shop_no)));
			
			echo json_encode($alotment);

		
			
		}


		$this->autoRender = false;
	}
}
