<?php
App::uses('AppController', 'Controller');
/**
 * AlotmentTypes Controller
 *
 * @property AlotmentType $AlotmentType
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class AlotmentTypesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Alotment type List');
		$this->AlotmentType->recursive = 0;
		$this->paginate = array('order' => array('AlotmentType.id' => 'DESC'));
		$this->set('alotmentTypes', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Alotment type Details');
		if (!$this->AlotmentType->exists($id)) {
			throw new NotFoundException(__('Invalid alotment type'));
		}
		$options = array('conditions' => array('AlotmentType.' . $this->AlotmentType->primaryKey => $id));
		$this->set('alotmentType', $this->AlotmentType->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Alotment type');
		if ($this->request->is('post')) {
			$this->AlotmentType->create();
			$this->request->data['AlotmentType']['created_at'] = $this->current_datetime();
			$this->request->data['AlotmentType']['user_id'] = $this->UserAuth->getUserId();			
			if ($this->AlotmentType->save($this->request->data)) {
				$this->Session->setFlash(__('The alotment type has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The alotment type could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$users = $this->AlotmentType->User->find('list');
		$this->set(compact('users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Alotment type');
		$this->AlotmentType->id = $id;
		if (!$this->AlotmentType->exists($id)) {
			throw new NotFoundException(__('Invalid alotment type'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			
			$this->request->data['AlotmentType']['updated_at'] = $this->current_datetime();
			$this->request->data['AlotmentType']['user_id'] = $this->UserAuth->getUserId();
			if ($this->AlotmentType->save($this->request->data)) {
				$this->Session->setFlash(__('The alotment type has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The alotment type could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('AlotmentType.' . $this->AlotmentType->primaryKey => $id));
			$this->request->data = $this->AlotmentType->find('first', $options);
		}
		$users = $this->AlotmentType->User->find('list');
		$this->set(compact('users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->AlotmentType->id = $id;
		if (!$this->AlotmentType->exists()) {
			throw new NotFoundException(__('Invalid alotment type'));
		}
		if ($this->AlotmentType->delete()) {
			$this->Session->setFlash(__('Alotment type deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Alotment type was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}
}
