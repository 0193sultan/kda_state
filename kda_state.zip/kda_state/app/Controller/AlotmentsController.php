<?php
App::uses('AppController', 'Controller');
/**
 * Alotments Controller
 *
 * @property Alotment $Alotment
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class AlotmentsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Alotment List');
		$this->Alotment->recursive = 0;
		$this->paginate = array('order' => array('Alotment.id' => 'DESC'));
		$this->set('alotments', $this->paginate());

		$this->loadModel('ProjectName');
		$ProjectNames = $this->ProjectName->find('list');

		$this->set(compact('ProjectNames'));
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Alotment Details');
		if (!$this->Alotment->exists($id)) {
			throw new NotFoundException(__('Invalid alotment'));
		}
		$options = array('conditions' => array('Alotment.' . $this->Alotment->primaryKey => $id));
		$this->set('alotment', $this->Alotment->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Alotment');
		if ($this->request->is('post')) {
			$this->Alotment->create();
			$this->request->data['Alotment']['created_at'] = $this->current_datetime();
			$this->request->data['Alotment']['user_id'] = $this->UserAuth->getUserId();
			$this->request->data['Alotment']['alotment_date'] = date("Y-m-d", strtotime($this->request->data['Alotment']['alotment_date']));

			if ($this->Alotment->save($this->request->data)) {
				$this->Session->setFlash(__('The alotment has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The alotment could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$projectNames = $this->Alotment->ProjectName->find('list');
		$alotmentTypes = $this->Alotment->AlotmentType->find('list');
		$ploatTypes = $this->Alotment->PloatType->find('list');
		$users = $this->Alotment->User->find('list');
		$this->set(compact('projectNames', 'alotmentTypes', 'ploatTypes', 'users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Alotment');
		$this->Alotment->id = $id;
		if (!$this->Alotment->exists($id)) {
			throw new NotFoundException(__('Invalid alotment'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['Alotment']['updated_at'] = $this->UserAuth->getUserId();
			$this->request->data['Alotment']['alotment_date'] = date("Y-m-d", strtotime($this->request->data['Alotment']['alotment_date']));
			if ($this->Alotment->save($this->request->data)) {
				$this->Session->setFlash(__('The alotment has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The alotment could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('Alotment.' . $this->Alotment->primaryKey => $id));
			$this->request->data = $this->Alotment->find('first', $options);
		}
		$projectNames = $this->Alotment->ProjectName->find('list');
		$alotmentTypes = $this->Alotment->AlotmentType->find('list');
		$ploatTypes = $this->Alotment->PloatType->find('list');
		$users = $this->Alotment->User->find('list');
		$this->set(compact('projectNames', 'alotmentTypes', 'ploatTypes', 'users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->Alotment->id = $id;
		if (!$this->Alotment->exists()) {
			throw new NotFoundException(__('Invalid alotment'));
		}
		if ($this->Alotment->delete()) {
			$this->Session->setFlash(__('Alotment deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Alotment was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}

	public function admin_serach_project_name()
	{
		if($this->request->is('post'))
		{
			$all = $this->request->data;
			
			function input($data) {
			  $data = trim($data);
			  $data = stripslashes($data);
			  $data = htmlspecialchars($data);
			  return $data;
			}
			$name = input($all['name']);
			
			if($name == 0)
			{
				$this->redirect(array('action' => 'index'));
			}
			else
			{
				$this->set('page_title','Alotment Search');
				$this->Alotment->recursive = 0;
				$alotments = $this->Alotment->find('all',array('conditions' => array('project_name_id' => $name)));

				$this->set(compact('alotments'));
				$test =  array();
				$this->set('test', $this->paginate());
			}			

			
		}

		$ProjectNames = $this->Alotment->ProjectName->find('list');
		$this->set(compact('ProjectNames'));

	}
}
