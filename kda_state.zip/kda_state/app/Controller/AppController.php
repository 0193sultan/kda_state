<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

 
/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {
	
	public $theme = "CakeAdminLTE";
	var $helpers = array('App', 'Form', 'Html', 'Session', 'Js', 'Usermgmt.UserAuth');
	public $components = array('Session','RequestHandler','App','Usermgmt.UserAuth');
	
	
	function beforeFilter(){
		/* if($this->request->params['controller'] == 'products'){
			return true;	
		} */
		
		if($this->UserAuth->getUserId() == '' AND $this->request->params['action'] == 'login')
		{
			return true;
		}else if($this->UserAuth->getUserId() == '' AND $this->request->params['action'] != 'login' AND $this->request->params['controller'] != 'api_data_retrives'){
			$this->Session->setFlash('You need to be signed in to view this page.');
			$this->redirect('/admin/login');
		}	
		
				
		if($this->RequestHandler->isAjax() OR $this->request->params['controller'] == 'api_data_retrives'){
			
		}else{
			$this->userAuth();
			$this->set('page_title', 'DashBoards');
			$side_menu = $this->side_menu();
			$this->set('menu',$side_menu);
		}		
		//parent::beforeFilter();
	}
	
	private function userAuth()
	{		
		$this->UserAuth->beforeFilter($this);
	}
	
	private function side_menu()
	{		
			$menu = array(
				'allUsers' => array('title'=>'WarterSupplySettings','controller'=>'WarterSupplySettings','action'=>'index','icon' => '<i class="fa fa-user"></i>','scroll' => '0',
							'child' => array(
								'allUsers' => array('title'=>'Index','controller'=>'WarterSupplySettings','action'=>'index'),
								'allGroups' => array('title'=>'User Groups','controller'=>'WarterSupplySettings','action'=>'index'),
								'permissions' => array('title'=>'Group Permissions','controller'=>'WarterSupplySettings','action'=>'index'),
								) ),
				'PloatTypes' => array('title'=>'PloatTypes','controller'=>'PloatTypes','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
							'child' => array(
								'PloatTypes' => array('title'=>'PloatTypes List','controller'=>'PloatTypes','action'=>'admin_index'),
								'PloatTypes/add' => array('title'=>'PloatTypes Add','controller'=>'PloatTypes','action'=>'admin_add')
						
				)),
				'AlotmentTypes' => array('title'=>'AlotmentTypes','controller'=>'AlotmentTypes','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
							'child' => array(
								'AlotmentTypes' => array('title'=>'AlotmentTypes List','controller'=>'AlotmentTypes','action'=>'admin_index'),
								'AlotmentTypes/add' => array('title'=>'AlotmentTypes Add','controller'=>'AlotmentTypes','action'=>'admin_add')
						
				)),
				'LandAcquisitions' => array('title'=>'LandAcquisitions','controller'=>'LandAcquisitions','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
							'child' => array(
								'LandAcquisitions' => array('title'=>'LandAcquisitions List','controller'=>'LandAcquisitions','action'=>'admin_index'),
								'LandAcquisitions/add' => array('title'=>'LandAcquisitions Add','controller'=>'LandAcquisitions','action'=>'admin_add')
						
				)),
				'ProjectNames' => array('title'=>'ProjectNames','controller'=>'ProjectNames','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
											'child' => array(
												'ProjectNames' => array('title'=>'ProjectNames List','controller'=>'ProjectNames','action'=>'admin_index'),
												'ProjectNames/add' => array('title'=>'ProjectNames Add','controller'=>'ProjectNames','action'=>'admin_add')
										
								)),
				'Plots' => array('title'=>'Plots','controller'=>'Plots','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
											'child' => array(
												'Plots' => array('title'=>'Plots List','controller'=>'Plots','action'=>'admin_index'),
												'Plots/add' => array('title'=>'Plots Add','controller'=>'Plots','action'=>'admin_add')
										
								)),
				'Alotments' => array('title'=>'Alotments','controller'=>'Alotments','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
											'child' => array(
												'Alotments' => array('title'=>'Alotments List','controller'=>'Alotments','action'=>'admin_index'),
												'Alotments/add' => array('title'=>'Alotments Add','controller'=>'Alotments','action'=>'admin_add')
										
								)),
				'AlotmentTransfers' => array('title'=>'AlotmentTransfers','controller'=>'AlotmentTransfers','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
															'child' => array(
																'AlotmentTransfers' => array('title'=>'AlotmentTransfers List','controller'=>'AlotmentTransfers','action'=>'admin_index'),
																'AlotmentTransfers/add' => array('title'=>'AlotmentTransfers Add','controller'=>'AlotmentTransfers','action'=>'admin_add')
														
												)),
				'Collections' => array('title'=>'Collections','controller'=>'Collections','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
											'child' => array(
												'Collections' => array('title'=>'Collections List','controller'=>'Collections','action'=>'admin_index'),
												'Collections/add' => array('title'=>'Collections Add','controller'=>'Collections','action'=>'admin_add')
										
								)),
				'CollectionHistories' => array('title'=>'CollectionHistories','controller'=>'CollectionHistories','action'=>'admin_index','icon' => '<i class="fa fa-shopping-cart"></i>','scroll' => '0',
															'child' => array(
																'CollectionHistories' => array('title'=>'CollectionHistories List','controller'=>'CollectionHistories','action'=>'admin_index'),
																'CollectionHistories/add' => array('title'=>'CollectionHistories Add','controller'=>'CollectionHistories','action'=>'admin_add')
														
												))
			
		);
		
		
		return $menu;
	}
	
	
	public function current_datetime()
	{
		date_default_timezone_set('Asia/Dhaka');
		return date('Y-m-d H:i:s');
	}
	
	public function current_date()
	{
		date_default_timezone_set('Asia/Dhaka');
		return date('Y-m-d');
	}
	
	public function to_expire_date($date)
	{
		date_default_timezone_set('Asia/Dhaka');
		$date = explode("-",$date);
		$new_date = "01-".$date[0]."-20".$date[1];
		return Date("Y-m-t", strtotime($new_date));
	}
	
	public function from_expire_date($date)
	{
		date_default_timezone_set('Asia/Dhaka');		
		return Date("m-y", strtotime($date));
	}
	
	// unit convert to base unit
	public function unit_convert($product_id='',$measurement_unit_id='',$qty='')
	{
		$this->loadModel('ProductMeasurement');
		$unit_info = $this->ProductMeasurement->find('first',array(
			'conditions' => array(
				'ProductMeasurement.product_id' => $product_id,
				'ProductMeasurement.measurement_unit_id' => $measurement_unit_id
			)
		));
		if(!empty($unit_info))
		{
			return sprintf('%.2f',($unit_info['ProductMeasurement']['qty_in_base'] * $qty));
		}else{
			return sprintf('%.2f',$qty);
		}
	}
	
	// unit convert to other unit
	public function unit_convertfrombase($product_id='',$measurement_unit_id='',$qty='')
	{
		$this->loadModel('ProductMeasurement');
		$unit_info = $this->ProductMeasurement->find('first',array(
			'conditions' => array(
				'ProductMeasurement.product_id' => $product_id,
				'ProductMeasurement.measurement_unit_id' => $measurement_unit_id
			)
		));
		if(!empty($unit_info))
		{
			$qty = floor($qty/$unit_info['ProductMeasurement']['qty_in_base']);
			return sprintf('%.2f',$qty);
		}else{
			return sprintf('%.2f',$qty);
		}
	}
	
	// convert unit to unit
	public function convert_unit_to_unit($product_id='',$from_unit_id='',$to_unit_id='',$qty='')
	{
		$this->loadModel('ProductMeasurement');
		$from_unit_info = $this->ProductMeasurement->find('first',array(
			'conditions' => array(
				'ProductMeasurement.product_id' => $product_id,
				'ProductMeasurement.measurement_unit_id' => $from_unit_id				
			),
			'recursive' => -1
		));
				
		if(!empty($from_unit_info))
		{
			$from_quantity = $qty * $from_unit_info['ProductMeasurement']['qty_in_base'];
		}else{
			$from_quantity = $qty;
		}
				
		$to_unit_info = $this->ProductMeasurement->find('first',array(
			'conditions' => array(
				'ProductMeasurement.product_id' => $product_id,
				'ProductMeasurement.measurement_unit_id' => $to_unit_id
			)
		));
		if(!empty($to_unit_info))
		{
			$to_quantity = $to_unit_info['ProductMeasurement']['qty_in_base'];
		}else{
			$to_quantity = 1;
		}
		
		return sprintf('%.2f',($from_quantity/$to_quantity));
	}
	
	
	function buildTree(array $elements, $parentId = 0) {
		$branch = array();

		foreach ($elements as $element) {
			if ($element['parent_id'] == $parentId) {
				$children = $this->buildTree($elements, $element['id']);
				if ($children) {
					$element['children'] = $children;
				}
				$branch[] = $element;
			}
		}

		return $branch;
	}
	
	function array_flatten(array $array)
	{
		$flat = array(); // initialize return array
		$stack = array_values($array); // initialize stack
		while($stack) // process stack until done
		{
			$value = array_shift($stack);
			if (is_array($value)) // a value to further process
			{
				$stack = array_merge(array_values($value), $stack);
			}
			else // a value to take
			{
			   $flat[] = $value;
			}
		}
		return $flat;
	}
	
	
	public function p($data)
	{
		echo '<pre>';
		print_r($data);
		echo '</pre>';
	}
	
	public function page_limit()
	{
		if(isset($this->request->data['page_limit']) == '')
		{
			$this->request->data['page_limit'] = 20;
			return 20;
		}else{
			return $this->request->data['page_limit'];
		}		
	}
	
	/* public function buildTree(Array $data, $parent_id = 0) {
		$tree = array();
		foreach ($data as $key => $val) {
			if ($val['parent_id'] == $parent_id) {
				$children = $this->buildTree($data, $val['id']);
				// set a trivial key
				if (!empty($children)) {
					$d['_children'] = $children;
				}
				$tree[] = $d;
			}
		}
		return $tree;
	}  */
	
	public function get_store_list($store_type_id='')
	{
		$this->loadModel('Store');
		
		if($store_type_id == 1 OR $store_type_id == 2)
		{
			$virtualFields = array(
				'name' => "CONCAT(Store.name, ' (', SalesPerson.name,')')"
			);
			
			$receiver_store = $this->Store->find('all', array(
				'joins' => array(
					array(
						'table' => 'sales_people',
						'alias' => 'SalesPerson',
						'type' => 'left',
						'conditions' => array(
							'SalesPerson.office_id = Store.office_id AND SalesPerson.designation_id <= 2'					
						)
					)
				),
				'conditions' => array('store_type_id' => $store_type_id),
				'fields' => array('Store.name','SalesPerson.name'),
				'order' => array('Store.name'=>'asc'),
				'recursive' => -1
			));
			
			return $receiver_store;
		
		}else if($store_type_id == 3)
		{
			
		}
		
	}	
	
}
