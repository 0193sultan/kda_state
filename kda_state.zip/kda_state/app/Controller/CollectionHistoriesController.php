<?php
App::uses('AppController', 'Controller');
/**
 * Collections Controller
 *
 * @property Collection $Collection
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class CollectionHistoriesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index()
	{
		if($this->request->is('post'))
		{
			$this->loadModel('Collection');
			$this->loadModel('Alotment');
			$all = $this->request->data;

			$project_name_id = $all['CollectionHistories']['project_name_id'];
			$ploat_type_id = $all['CollectionHistories']['ploat_type_id'];
			$plot_shop_no = $all['CollectionHistories']['plot_shop_no'];
			$start_date = date("Y-m-d", strtotime($all['CollectionHistories']['start_date']));
			$end_date = date('Y-m-d', strtotime($all['CollectionHistories']['end_date']));

			$between_con = array('Collection.deposit_date >=' => $start_date, 'Collection.deposit_date <=' => $end_date);

			$alotm = $this->Alotment->find('all',array('conditions' => array('Alotment.project_name_id' => $project_name_id, 'Alotment.ploat_type_id' => $ploat_type_id, 'Alotment.plot_shop_billboard_no' => $plot_shop_no)));

			$res = $this->Collection->find('all',array('conditions' => array('Collection.project_name_id' => $project_name_id, 'Collection.ploat_type_id' => $ploat_type_id, 'Collection.plot_shop_no' => $plot_shop_no, 'AND' => array($between_con))));

			$this->set(compact('res','alotm'));
		}

		$this->loadModel('ProjectName');
		$ProjectNames = $this->ProjectName->find('list');

		$this->loadModel('PloatType');
		$PloatType = $this->PloatType->find('list');

		$this->set(compact('ProjectNames','PloatType'));

	}
}