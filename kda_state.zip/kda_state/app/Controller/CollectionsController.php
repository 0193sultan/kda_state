<?php
App::uses('AppController', 'Controller');
/**
 * Collections Controller
 *
 * @property Collection $Collection
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class CollectionsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Collection List');
		$this->Collection->recursive = 0;
		$this->paginate = array('order' => array('Collection.id' => 'DESC'));
		$this->set('collections', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Collection Details');
		if (!$this->Collection->exists($id)) {
			throw new NotFoundException(__('Invalid collection'));
		}
		$options = array('conditions' => array('Collection.' . $this->Collection->primaryKey => $id));
		$this->set('collection', $this->Collection->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Collection');
		if ($this->request->is('post')) {
			$this->Collection->create();
			$this->request->data['Collection']['created_at'] = $this->current_datetime();
			$this->request->data['Collection']['user_id'] = $this->UserAuth->getUserId();			
			$this->request->data['Collection']['deposit_date'] = date("Y-m-d", strtotime($this->request->data['Collection']['deposit_date']));			
			if ($this->Collection->save($this->request->data)) {
				$this->Session->setFlash(__('The collection has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The collection could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$projectNames = $this->Collection->ProjectName->find('list');
		$ploatTypes = $this->Collection->PloatType->find('list');
		$alotmentTypes = $this->Collection->AlotmentType->find('list');
		$users = $this->Collection->User->find('list');
		$this->set(compact('projectNames', 'ploatTypes', 'alotmentTypes', 'users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Collection');
		$this->Collection->id = $id;
		if (!$this->Collection->exists($id)) {
			throw new NotFoundException(__('Invalid collection'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['Collection']['updated_at'] = $this->current_datetime();
			$this->request->data['Collection']['user_id'] = $this->UserAuth->getUserId();
			$this->request->data['Collection']['deposit_date'] = date("Y-m-d", strtotime($this->request->data['Collection']['deposit_date']));

			if ($this->Collection->save($this->request->data)) {
				$this->Session->setFlash(__('The collection has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The collection could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('Collection.' . $this->Collection->primaryKey => $id));
			$this->request->data = $this->Collection->find('first', $options);
		}
		$projectNames = $this->Collection->ProjectName->find('list');
		$ploatTypes = $this->Collection->PloatType->find('list');
		$alotmentTypes = $this->Collection->AlotmentType->find('list');
		$users = $this->Collection->User->find('list');
		$this->set(compact('projectNames', 'ploatTypes', 'alotmentTypes', 'users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->Collection->id = $id;
		if (!$this->Collection->exists()) {
			throw new NotFoundException(__('Invalid collection'));
		}
		if ($this->Collection->delete()) {
			$this->Session->setFlash(__('Collection deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Collection was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}

	public function get_call()
	{
		if($this->request->is('post'))
		{
			$plot_shop_no = $this->request->data['plot_shop_no'];

			$this->loadModel('Alotment');

			$rs = $this->Alotment->find('all',array('fields' => array('alotment_receiver'), 'conditions' => array('plot_shop_billboard_no' => $plot_shop_no)));
			if(!empty($rs))
			{
				$alt_rsver_name = $rs[0]['Alotment']['alotment_receiver'];

				echo  $alt_rsver_name;
			}
			else
			{
				echo 'error';
			}

			
		}

		$this->autoRender = false;
	}
}
