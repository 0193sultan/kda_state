<?php
App::uses('AppController', 'Controller');
/**
 * LandAcquisitions Controller
 *
 * @property LandAcquisition $LandAcquisition
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class LandAcquisitionsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Land acquisition List');
		$this->LandAcquisition->recursive = 0;
		$this->paginate = array('order' => array('LandAcquisition.id' => 'DESC'));
		$this->set('landAcquisitions', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Land acquisition Details');
		if (!$this->LandAcquisition->exists($id)) {
			throw new NotFoundException(__('Invalid land acquisition'));
		}
		$options = array('conditions' => array('LandAcquisition.' . $this->LandAcquisition->primaryKey => $id));
		$this->set('landAcquisition', $this->LandAcquisition->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Land acquisition');
		if ($this->request->is('post')) {
			$this->LandAcquisition->create();
			$this->request->data['LandAcquisition']['created_at'] = $this->current_datetime();
			$this->request->data['LandAcquisition']['user_id'] = $this->UserAuth->getUserId();			
			if ($this->LandAcquisition->save($this->request->data)) {
				$this->Session->setFlash(__('The land acquisition has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The land acquisition could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$users = $this->LandAcquisition->User->find('list');
		$this->set(compact('users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Land acquisition');
		$this->LandAcquisition->id = $id;
		if (!$this->LandAcquisition->exists($id)) {
			throw new NotFoundException(__('Invalid land acquisition'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			
			$this->request->data['LandAcquisition']['updated_at'] = $this->current_datetime();

			$this->request->data['LandAcquisition']['user_id'] = $this->UserAuth->getUserId();
			if ($this->LandAcquisition->save($this->request->data)) {
				$this->Session->setFlash(__('The land acquisition has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The land acquisition could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('LandAcquisition.' . $this->LandAcquisition->primaryKey => $id));
			$this->request->data = $this->LandAcquisition->find('first', $options);
		}
		$users = $this->LandAcquisition->User->find('list');
		$this->set(compact('users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->LandAcquisition->id = $id;
		if (!$this->LandAcquisition->exists()) {
			throw new NotFoundException(__('Invalid land acquisition'));
		}
		if ($this->LandAcquisition->delete()) {
			$this->Session->setFlash(__('Land acquisition deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Land acquisition was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}

	public function admin_lacase_search()
	{
		if($this->request->is('post'))
		{
			$all = $this->request->data;
			function input($data) {
			  $data = trim($data);
			  $data = stripslashes($data);
			  $data = htmlspecialchars($data);
			  return $data;
			}
			$la_no = input($all['la']);
			

			$this->set('page_title','Land acquisition List');
			$this->LandAcquisition->recursive = 0;
			$landAcquisitions = $this->LandAcquisition->find('all',array('conditions' => array('LandAcquisition.la_case_no' => $la_no)));

			$this->set(compact('landAcquisitions'));
			$this->set('test', $this->paginate());
		}
		
	}
}
