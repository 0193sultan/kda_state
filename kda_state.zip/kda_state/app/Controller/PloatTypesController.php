<?php
App::uses('AppController', 'Controller');
/**
 * PloatTypes Controller
 *
 * @property PloatType $PloatType
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class PloatTypesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Ploat type List');
		$this->PloatType->recursive = 0;
		$this->paginate = array('order' => array('PloatType.id' => 'DESC'));
		$this->set('ploatTypes', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Ploat type Details');
		if (!$this->PloatType->exists($id)) {
			throw new NotFoundException(__('Invalid ploat type'));
		}
		$options = array('conditions' => array('PloatType.' . $this->PloatType->primaryKey => $id));
		$this->set('ploatType', $this->PloatType->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Ploat type');
		if ($this->request->is('post')) {
			$this->PloatType->create();
			$this->request->data['PloatType']['created_at'] = $this->current_datetime();
			$this->request->data['PloatType']['user_id'] = $this->UserAuth->getUserId();			
			if ($this->PloatType->save($this->request->data)) {
				$this->Session->setFlash(__('The ploat type has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ploat type could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$users = $this->PloatType->User->find('list');
		$this->set(compact('users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Ploat type');
		$this->PloatType->id = $id;
		if (!$this->PloatType->exists($id)) {
			throw new NotFoundException(__('Invalid ploat type'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['PloatType']['updated_at'] = $this->current_datetime();
			$this->request->data['PloatType']['user_id'] = $this->UserAuth->getUserId();
			if ($this->PloatType->save($this->request->data)) {
				$this->Session->setFlash(__('The ploat type has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ploat type could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('PloatType.' . $this->PloatType->primaryKey => $id));
			$this->request->data = $this->PloatType->find('first', $options);
		}
		$users = $this->PloatType->User->find('list');
		$this->set(compact('users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->PloatType->id = $id;
		if (!$this->PloatType->exists()) {
			throw new NotFoundException(__('Invalid ploat type'));
		}
		if ($this->PloatType->delete()) {
			$this->Session->setFlash(__('Ploat type deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Ploat type was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}
}
