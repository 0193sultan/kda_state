<?php
App::uses('AppController', 'Controller');
/**
 * Plots Controller
 *
 * @property Plot $Plot
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class PlotsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Plot List');
		$this->Plot->recursive = 0;
		$this->paginate = array('order' => array('Plot.id' => 'DESC'));
		$this->set('plots', $this->paginate());

		$projectNames = $this->Plot->ProjectName->find('list');
		$this->set(compact('projectNames'));
	}


	/*public function admin_alotment_type($tid = null)
	{
		$this->loadModel('ConfigMeta');

		$alotment_type = $this->ConfigMeta->find('all', array('fields' => array('value'), 'conditions' => array('trackingId' =>$tid)));
		return $alotment_type;
	}*/

	public function admin_ttl_plot_quantity($plot_id = null)
	{
		$this->loadModel('PlotCategorie');

		$pq_sum = $this->PlotCategorie->find('all', array('fields' => array('sum(plot_quantity) as plot_quantity'), 'conditions' => array('plot_id' =>$plot_id)));
		
		return $pq_sum;
	}

	public function admin_plot_category_by_id($plot_id = null)
	{
		$this->loadModel('PlotCategorie');

		$all = $this->PlotCategorie->find('all', array('conditions' => array('plot_id' =>$plot_id)));
		
		return $all;
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Plot Details');
		if (!$this->Plot->exists($id)) {
			throw new NotFoundException(__('Invalid plot'));
		}
		$options = array('conditions' => array('Plot.' . $this->Plot->primaryKey => $id));
		$this->set('plot', $this->Plot->find('first', $options));

	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		
		$this->set('page_title','Add Plot');
		
		if ($this->request->is('post')) {
			
			$all = $this->request->data;
			$er = 0;

			if(empty($all['pc']))
			{
				$this->Session->setFlash(__('The plot could not be saved. Please, try again.'), 'flash/error');
				$this->redirect(array('action' => 'index'));
			}
		
			##############################################################
			###### Plot Entry start
			#############################################################

			$data['Plot']['created_at'] = $this->current_datetime();
			$data['Plot']['user_id'] = $this->UserAuth->getUserId();
			$data['Plot']['project_name_id'] = $all['Plot']['project_name_id'];
			$data['Plot']['ploat_type_id'] = $all['Plot']['ploat_type_id'];
			$data['Plot']['alotment_type_id'] = $all['Plot']['alotment_type_id'];

			$this->Plot->create();
			$ck = $this->Plot->save($data);
			$insertedId = $this->Plot->getLastInsertId();

			if(!$ck)
			{
				$er = 1;
			}

			##############################################################
			###### Plot Entry End
			#############################################################


			##############################################################
			###### plot_categories Start
			##############################################################

			$l = count($all['pc']);
			$this->loadModel('PlotCategorie');

			for($i = 0; $i<$l; $i++)
			{
				$data_2['plot_id']	= $insertedId;
				$data_2['name'] = $all['pc'][$i];
				$data_2['plot_size'] = $all['ps'][$i];
				$data_2['unit'] = $all['unit'][$i];
				$data_2['plot_quantity'] = $all['pq'][$i];
				$data_2['user_id'] = $this->UserAuth->getUserId();
				$data_2['created_at'] = $this->current_datetime();

				$this->PlotCategorie->create();
				$ck = $this->PlotCategorie->save($data_2);

				if(!$ck)
				{
					$er = 1;
				}

			}

			##############################################################
			###### plot_categories End
			##############################################################
						
			if ($ck) {
				$this->Session->setFlash(__('The plot has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The plot could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$projectNames = $this->Plot->ProjectName->find('list');
		$ploatTypes = $this->Plot->PloatType->find('list');
		$users = $this->Plot->User->find('list');
		$alotmentTypes = $this->Plot->AlotmentType->find('list');

		$this->set(compact('projectNames', 'ploatTypes', 'users','alotmentTypes'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Plot');
		$this->Plot->id = $id;
		if (!$this->Plot->exists($id)) {
			throw new NotFoundException(__('Invalid plot'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {

			####################################################################
			##### we need to update 2 tables start from here
			####################################################################

			$all =  $this->request->data;
			//pr($all); exit();
			$er = 0;
			
			$polt_data['Plot']['user_id'] = $this->UserAuth->getUserId();
			$polt_data['Plot']['updated_at'] = $this->current_datetime();
			$polt_data['Plot']['project_name_id'] = $all['Plot']['project_name_id'];
			$polt_data['Plot']['ploat_type_id'] = $all['Plot']['ploat_type_id'];
			$polt_data['Plot']['alotment_type_id'] = $all['Plot']['alotment_type_id'];

			$ck = $this->Plot->save($polt_data);

			if(!$ck)
			{
				$er = 1;
			}

			$this->loadModel('PlotCategorie');
			$l = count($all['id']);

			for($i = 0; $i < $l; $i++)
			{
				$plot_cat_data['PlotCategorie']['plot_id'] = $all['Plot']['id'];
				$plot_cat_data['PlotCategorie']['name'] = $all['name'][$i];
				$plot_cat_data['PlotCategorie']['plot_size'] = $all['ps'][$i];
				$plot_cat_data['PlotCategorie']['plot_quantity'] = $all['pq'][$i];
				$plot_cat_data['PlotCategorie']['updated_at'] = $this->current_datetime();
				$plot_cat_data['PlotCategorie']['user_id'] = $this->UserAuth->getUserId();

				$id = $all['id'][$i];

				$this->PlotCategorie->id = $id;
				if (!$this->PlotCategorie->exists($id)) {
					throw new NotFoundException(__('Invalid PlotCategorie'));
				}

				$ck = $this->PlotCategorie->save($plot_cat_data);

				if(!$ck)
				{
					$er = 1;
				}

			}


			####################################################################
			##### Update 2 tables end here
			####################################################################
			if ($er != 1) {
				$this->Session->setFlash(__('The plot has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The plot could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('Plot.' . $this->Plot->primaryKey => $id));
			$this->request->data = $this->Plot->find('first', $options);
		}
		$projectNames = $this->Plot->ProjectName->find('list');
		$ploatTypes = $this->Plot->PloatType->find('list');
		$alotmentTypes = $this->Plot->AlotmentType->find('list');
		$users = $this->Plot->User->find('list');
		$this->set(compact('projectNames', 'ploatTypes', 'users','alotmentTypes'));

		
		$this->set(compact('id'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->Plot->id = $id;
		if (!$this->Plot->exists()) {
			throw new NotFoundException(__('Invalid plot'));
		}

		##########################################################
		#######	Multiple delete plot category start
		###########################################################
				$this->loadModel('PlotCategorie');
				$pc_id = $this->PlotCategorie->find('all',array('fields' => array('id'), 'conditions' => array('plot_id' => $id) ));
				
				foreach ($pc_id as $v) 
				{
					$id =  $v['PlotCategorie']['id'];
					$this->PlotCategorie->id = $id;
					if (!$this->PlotCategorie->exists()) {
						throw new NotFoundException(__('PlotCategorie id'));
					}

					$this->PlotCategorie->delete();
				}


		##########################################################
		#######	Multiple delete plot category End
		###########################################################

		if ($this->Plot->delete()) {
			$this->Session->setFlash(__('Plot deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Plot was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}

	public function admin_project_name_search()
	{
		if($this->request->is('post'))
		{
			$all = $this->request->data;
			function input($data) {
			  $data = trim($data);
			  $data = stripslashes($data);
			  $data = htmlspecialchars($data);
			  return $data;
			}
			$name = input($all['name']);
			
			if($name == 0)
			{
				$this->redirect(array('action' => 'index'));
			}
			else
			{
				$this->set('page_title','Plot Search');
				$this->Plot->recursive = 0;
				$plots = $this->Plot->find('all',array('conditions' => array('project_name_id' => $name)));

				$this->set(compact('plots'));
				$this->set('test', $this->paginate());
			}			

			
		}
		$projectNames = $this->Plot->ProjectName->find('list');
		$this->set(compact('projectNames'));

	}

}
