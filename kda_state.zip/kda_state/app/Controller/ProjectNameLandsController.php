<?php
App::uses('AppController', 'Controller');
/**
 * ProjectNameLands Controller
 *
 * @property ProjectNameLand $ProjectNameLand
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class ProjectNameLandsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Project name land List');
		$this->ProjectNameLand->recursive = 0;
		$this->paginate = array('order' => array('ProjectNameLand.id' => 'DESC'));
		$this->set('projectNameLands', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Project name land Details');
		if (!$this->ProjectNameLand->exists($id)) {
			throw new NotFoundException(__('Invalid project name land'));
		}
		$options = array('conditions' => array('ProjectNameLand.' . $this->ProjectNameLand->primaryKey => $id));
		$this->set('projectNameLand', $this->ProjectNameLand->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Project name land');
		if ($this->request->is('post')) {
			$this->ProjectNameLand->create();
			$this->request->data['ProjectNameLand']['created_at'] = $this->current_datetime();
			$this->request->data['ProjectNameLand']['created_by'] = $this->UserAuth->getUserId();			
			if ($this->ProjectNameLand->save($this->request->data)) {
				$this->Session->setFlash(__('The project name land has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The project name land could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$projectNames = $this->ProjectNameLand->ProjectName->find('list');
		$users = $this->ProjectNameLand->User->find('list');
		$this->set(compact('projectNames', 'users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Project name land');
		$this->ProjectNameLand->id = $id;
		if (!$this->ProjectNameLand->exists($id)) {
			throw new NotFoundException(__('Invalid project name land'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['ProjectNameLand']['updated_by'] = $this->UserAuth->getUserId();
			if ($this->ProjectNameLand->save($this->request->data)) {
				$this->Session->setFlash(__('The project name land has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The project name land could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('ProjectNameLand.' . $this->ProjectNameLand->primaryKey => $id));
			$this->request->data = $this->ProjectNameLand->find('first', $options);
		}
		$projectNames = $this->ProjectNameLand->ProjectName->find('list');
		$users = $this->ProjectNameLand->User->find('list');
		$this->set(compact('projectNames', 'users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->ProjectNameLand->id = $id;
		if (!$this->ProjectNameLand->exists()) {
			throw new NotFoundException(__('Invalid project name land'));
		}
		if ($this->ProjectNameLand->delete()) {
			$this->Session->setFlash(__('Project name land deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Project name land was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}
}
