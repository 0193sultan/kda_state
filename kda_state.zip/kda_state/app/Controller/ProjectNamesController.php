<?php
App::uses('AppController', 'Controller');
/**
 * ProjectNames Controller
 *
 * @property ProjectName $ProjectName
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class ProjectNamesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Project name List');
		$this->ProjectName->recursive = 0;
		$this->paginate = array('order' => array('ProjectName.id' => 'DESC'));
		$this->set('projectNames', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Project name Details');
		if (!$this->ProjectName->exists($id)) {
			throw new NotFoundException(__('Invalid project name'));
		}
		$options = array('conditions' => array('ProjectName.' . $this->ProjectName->primaryKey => $id));
		$this->set('projectName', $this->ProjectName->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Project name');
		if ($this->request->is('post')) {
			$this->ProjectName->create();
			$this->request->data['ProjectName']['created_at'] = $this->current_datetime();
			$this->request->data['ProjectName']['created_by'] = $this->UserAuth->getUserId();			
			if ($this->ProjectName->save($this->request->data)) {
				$this->Session->setFlash(__('The project name has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The project name could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$ploatTypes = $this->ProjectName->PloatType->find('list');
		$users = $this->ProjectName->User->find('list');

		$this->loadModel('LandAcquisition');
		$landacui = $this->LandAcquisition->find('all',array('fields' => array('LandAcquisition.id','LandAcquisition.la_case_no')));

		$this->set(compact('ploatTypes', 'users','landacui'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Project name');
		$this->ProjectName->id = $id;
		if (!$this->ProjectName->exists($id)) {
			throw new NotFoundException(__('Invalid project name'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['ProjectName']['updated_by'] = $this->UserAuth->getUserId();
			if ($this->ProjectName->save($this->request->data)) {
				$this->Session->setFlash(__('The project name has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The project name could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('ProjectName.' . $this->ProjectName->primaryKey => $id));
			$this->request->data = $this->ProjectName->find('first', $options);
		}
		$ploatTypes = $this->ProjectName->PloatType->find('list');
		$users = $this->ProjectName->User->find('list');
		$this->set(compact('ploatTypes', 'users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->ProjectName->id = $id;
		if (!$this->ProjectName->exists()) {
			throw new NotFoundException(__('Invalid project name'));
		}
		if ($this->ProjectName->delete()) {
			$this->Session->setFlash(__('Project name deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Project name was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}
}
