<?php
App::uses('AppController', 'Controller');
/**
 * ProjectNames Controller
 *
 * @property ProjectName $ProjectName
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class ProjectNamesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Project name List');
		$this->ProjectName->recursive = 0;
		$this->paginate = array('order' => array('ProjectName.id' => 'DESC'));
		$this->set('projectNames', $this->paginate());
	}

	public function admin_ttl_project_land($id = null)
	{
		$this->loadModel('ProjectNameLands');
		$ttl_land = $this->ProjectNameLands->find('all',array('fields' => array('sum(land_quantity) as land_quantity','land_quantity_unit as land_quantity_unit'), 'conditions' => array('project_name_id' => $id)));
		
		$flat = call_user_func_array('array_merge', $ttl_land);
		$ttl_land = call_user_func_array('array_merge', $flat);
		
		return $ttl_land;

		$this->autoRender = false;
	}

public function ttl_plot($id = 5)
{
	$this->loadModel('Plot');
	$this->loadModel('PlotCategory');
	$plot_id = $this->Plot->find('all',array('fields' => array('id'), 'conditions' => array('Plot.project_name_id' => $id)));

	$plot_id = $plot_id[0]['Plot']['id'];

	if(!empty($plot_id))
	{

	 $ttl_plot = $this->PlotCategory->find('all',array('fields' => array('sum(plot_quantity) as plot_quantity'), 'conditions' => array('PlotCategory.plot_id' => $plot_id)));

	 	if(!empty($ttl_plot))
	 	{
	 		$ttl_plot = $ttl_plot[0][0]['plot_quantity'];

	 		return $ttl_plot;
	 	}

	 	return false;
	}

	return false;

	$this->autoRender = false;
}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Project name Details');
		if (!$this->ProjectName->exists($id)) {
			throw new NotFoundException(__('Invalid project name'));
		}
		$options = array('conditions' => array('ProjectName.' . $this->ProjectName->primaryKey => $id));
		$this->set('projectName', $this->ProjectName->find('first', $options));

		$pnl = $this->project_name_lands($id);
		$this->set(compact('pnl'));
		
	}

	private function project_name_lands($id = null)
	{
		$this->loadModel('ProjectNameLands');
		$pnl = $this->ProjectNameLands->find('all',array('conditions' => array('project_name_id' => $id)));

		return $pnl;
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Project name');
		if ($this->request->is('post')) {

			####################################################################
			##### arafat.dml@gmail.com || arenaphonebd 
			##### submitted form data processing start
			##### here we insert the data in 3 tables -> 
			###### 1) land_acquisitions 2) project_names 2) project_name_lands
			####################################################################

			$er = 0;
			$all = $this->request->data;

			$projectData['ProjectName']['name'] = $all['ProjectName']['name'];
			$projectData['ProjectName']['ploat_type_id'] = $all['ProjectName']['ploat_type_id'];
			$projectData['ProjectName']['user_id'] = $this->UserAuth->getUserId();
			$projectData['ProjectName']['created_at'] = $this->current_datetime();
			$projectData['ProjectName']['project_establish_date'] = date("Y-m-d", strtotime($all['ProjectName']['project_establish_date']));


			$this->ProjectName->create();
			$pn_ck =  $this->ProjectName->save($projectData);
			$insertedId = $this->ProjectName->getLastInsertId();

			if($pn_ck)
			{
				$er = 0;
			}
			else
			{
				$er = 1;
			}

			$la_land = array();
			$key_la = array();
			$unit_unique = array();
			$res = array();
            
			########################################################################
			#####Creating unique array for 1) (la => land) N  2) unit
			########################################################################

			//pr($all);

			function chek($arr = array(), $val = null)
			{
				
			foreach ($arr as $k => $v) 
				{
					if($v == $val)
					{
						$key_la[] = $k;
					}
				}

				return $key_la;
			}

			foreach ($all['la'] as $value) 
			{
				$res = chek($all['la'],$value);
			}

			$res = array_unique($res); //this is the key array that contain duplicate value

			######################################################
			### All key that are duplicate and need to some
			######################################################
			$sum = 0;
			function sum($res = array(),$key = null)
			{
				foreach ($res as $v) 
				{
					if($v == $key)
					{
						return true;
					}
					
					return false;
				}
			}

			foreach($all['la'] as $k => $v)
			{
				$ck = sum($all['la'],$v);
				
				if($ck)
				{
					$sum = $sum + $all['land'][$k];
					$la_land[$v] = $sum;
					$unit_unique[$v] = $all['unit'][$k];

				}
				else
				{
					$la_land[$v] = $all['land'][$k];
					$unit_unique[$v] = $all['unit'][$k];
				}
			}

			############################################################
			###### All key that are duplicate and need to some end here
			#############################################################
			

			#####################################################################
			###### Creating unique arrays end here now we insert the data into
			###### 3 tables
			#####################################################################

			$this->loadModel('LandAcquisition');
			$this->loadModel('ProjectNameLand');

			foreach ($la_land as $k => $v) 
			{
				$res = $this->LandAcquisition->find('all', array('fields' => array('id','used','physical_acquisition'), 'conditions' => array('la_case_no' => $k)));
				//pr($res);
				
				$total_land = $res[0]['LandAcquisition']['physical_acquisition'];
				$use = $res[0]['LandAcquisition']['used'];
				$id  = $res[0]['LandAcquisition']['id'];

				$use = $use + $v;

				if($total_land < $use)
				{
					echo "<script> alert('You are giving a wrong entry')";
					$this->redirect(array('action' => 'index'));
				}
				else
				{
					$this->LandAcquisition->id = $id;
					if (!$this->LandAcquisition->exists($id)) {
						throw new NotFoundException(__('Invalid LandAcquisition use field update'));
					}
					$data['LandAcquisition']['used'] = $use;
					$la_ck = $this->LandAcquisition->save($data);
					if($la_ck)
					{
						$er = 0;
					}
					else
					{
						$er = 1;
					}
				}


				$projectNameLands_data['project_name_id'] = $insertedId;
				$projectNameLands_data['la_no'] = $k;
				$projectNameLands_data['land_quantity'] = $v;
				$projectNameLands_data['land_quantity_units'] = $unit_unique[$k];
				$projectNameLands_data['user_id'] = $this->UserAuth->getUserId();
				$projectNameLands_data['created_at'] = $this->current_datetime();

			$this->ProjectNameLand->create();
			$pnl_ck	= $this->ProjectNameLand->save($projectNameLands_data);

			if($pnl_ck)
			{
				$er = 0;
 			}
 			else
 			{
 				$er = 1;
 			}

			}

			if($er == 0)
			{
				$this->Session->setFlash(__('The project name has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			}
			else if($er == 1)
			{
				$this->Session->setFlash(__('The project name could not be saved. Please, try again.'), 'flash/error');
			}


			######################################################################
			#####Insert data into 2 table and update data one table end
			######################################################################
		}



		$ploatTypes = $this->ProjectName->PloatType->find('list');
		$users = $this->ProjectName->User->find('list');

		$this->loadModel('LandAcquisition');
		$landacui = $this->LandAcquisition->find('all',array('fields' => array('LandAcquisition.id','LandAcquisition.la_case_no')));

		$this->set(compact('ploatTypes', 'users','landacui'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Project name');
		$this->ProjectName->id = $id;
		if (!$this->ProjectName->exists($id)) {
			throw new NotFoundException(__('Invalid project name update'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {

			$all = $this->request->data;

			$la_land = array_combine($all['la'], $all['land']);
			
			############################################################################
			####### update 3 tables start here
			############################################################################

				########################################################################################
				##### ProjectName update start
				########################################################################################

				$projectNameUp['name'] = $all['ProjectName']['name'];
				$projectNameUp['ploat_type_id'] = $all['ProjectName']['ploat_type_id'];
				$projectNameUp['project_establish_date'] = date("Y-m-d", strtotime($all['ProjectName']['project_establish_date']));
				$projectNameUp['user_id'] = $this->UserAuth->getUserId();
				$projectNameUp['updated_at'] = $this->current_datetime();

				$ck = $this->ProjectName->save($projectNameUp);
				if(!$ck)
				{
					$er = 1;
				}


				########################################################################################
				##### ProjectName update End
				########################################################################################

			$this->loadModel('ProjectNameLand');
			$this->loadModel('LandAcquisition');
			$er = 0;
			
			foreach ($la_land as $key => $value) 
			{

				########################################################################################
				##### LandAcquisition used update start
				########################################################################################
				$used = $this->ProjectNameLand->find('all', array('fields' => array('id','land_quantity'),'conditions' => array('la_no' => $key)));

				$la_used = $this->LandAcquisition->find('all', array('fields' => array('id','used'),'conditions' => array('la_case_no' => $key)));
				

				$old_quantity = $used[0]['ProjectNameLand']['land_quantity'];
				$pnl_id = $used[0]['ProjectNameLand']['id'];

 				$la_use_update = $la_used[0]['LandAcquisition']['used'];
				$la_use_update_id = $la_used[0]['LandAcquisition']['id'];
				
				if($old_quantity < $value)
				{
					$land = $value - $old_quantity;
					$la_use_update = $la_use_update + $land;
				}
				else if($old_quantity > $value)
				{
					$land = $old_quantity - $value;
					$la_use_update = $la_use_update - $land;
				}
				else
				{
					$land = 0;
				}

				$data['LandAcquisition']['used'] = $la_use_update;
				$data['LandAcquisition']['updated_at'] = $this->current_datetime();
				$data['LandAcquisition']['user_id'] = $this->UserAuth->getUserId();

				$this->LandAcquisition->id = $la_use_update_id;
				if (!$this->LandAcquisition->exists($la_use_update_id)) {
					throw new NotFoundException(__('Invalid LandAcquisition update id'));
				}

				$ck = $this->LandAcquisition->save($data);
				if(!$ck)
				{
					$er = 1;
				}

				########################################################################################
				##### LandAcquisition used update end
				########################################################################################

				########################################################################################
				##### project_name_lands  update start
				########################################################################################

				$pnl_update['la_no'] = $key;
				$pnl_update['land_quantity'] = $value;
				$pnl_update['user_id'] = $this->UserAuth->getUserId();
				$pnl_update['updated_at'] = $this->current_datetime();

				$this->ProjectNameLand->id = $pnl_id;
				if (!$this->ProjectNameLand->exists($pnl_id)) {
					throw new NotFoundException(__('Invalid ProjectNameLand update id'));
				}

				$ck = $this->ProjectNameLand->save($pnl_update);
				if(!$ck)
				{
					$er = 1;
				}


				########################################################################################
				##### project_name_lands  update End
				########################################################################################
				
			}


			############################################################################
			####### update 3 tables start end
			############################################################################

			if ($er == 0) {
				$this->Session->setFlash(__('The project name has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The project name could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('ProjectName.' . $this->ProjectName->primaryKey => $id));
			$this->request->data = $this->ProjectName->find('first', $options);
		}
		$ploatTypes = $this->ProjectName->PloatType->find('list');
		$users = $this->ProjectName->User->find('list');
		$this->set(compact('ploatTypes', 'users'));

		$pnl = $this->project_name_lands($id);
		$this->set(compact('pnl'));


	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {

	##########################################################################################
	######### Here we need to delete 2 table data and update 1 table used column start  -->
	##########################################################################################

		$er = 0;

		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->ProjectName->id = $id;
		if (!$this->ProjectName->exists()) {
			throw new NotFoundException(__('Invalid project name'));
		}
		$ck = $this->ProjectName->delete();
		if(!$ck)
		{
			$er = 1;
		}

		$this->loadModel('ProjectNameLand');
		$this->loadModel('LandAcquisition');

		$res = $this->ProjectNameLand->find('all',array('fields' => array('id','la_no','land_quantity'), 'conditions' => array('project_name_id' => $id)));
		foreach ($res as $v) 
		{
			#################################################################
			####### LandAcquisition use update start here
			##################################################################
			$pnl_id = $v['ProjectNameLand']['id'];
			$pnl_la_no = $v['ProjectNameLand']['la_no'];
			$pnl_land_quantity = $v['ProjectNameLand']['land_quantity'];
			
			$r = $this->LandAcquisition->find('all',array('fields' => array('id','used'), 'conditions' => array('la_case_no' => $pnl_la_no)));

			$la_id = $r[0]['LandAcquisition']['id'];
			$la_used = $r[0]['LandAcquisition']['used'];

			$la_used = $la_used - $pnl_land_quantity;

			$this->LandAcquisition->id = $la_id;
			if ($this->LandAcquisition->id) 
			{
			    $ck = $this->LandAcquisition->saveField('used', $la_used);
			    if(!$ck)
			    {
			    	$er = 1;
			    }
			}

			#################################################################
			####### LandAcquisition use update end
			##################################################################

			#################################################################
			####### ProjectNameLand delete start here
			##################################################################

			$this->ProjectNameLand->id = $pnl_id;
			if (!$this->ProjectNameLand->exists()) {
				throw new NotFoundException(__('Invalid ProjectNameLand delete id'));
			}
			$ck = $this->ProjectNameLand->delete();
			if (!$ck) 
			{
				$er = 1;
			}

			#################################################################
			####### ProjectNameLand delete end
			##################################################################
		}

		if ($er != 1) 
		{
			$this->Session->setFlash(__('Project name deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Project name was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));

	##########################################################################################
	######### Here we need to delete 2 table data and update 1 table used column END
	##########################################################################################


	}


	public function get_call()
	{
		$id = $this->request->data('la_no');

		$this->loadModel('LandAcquisition');

		$res = $this->LandAcquisition->find('all', array('fields' => array('LandAcquisition.la_case_no', 'LandAcquisition.physical_acquisition','LandAcquisition.physical_acquisition_unit','used'), 'conditions' => array('LandAcquisition.id' => $id)));

			if(!empty($res))
			{

				$total = $res[0]['LandAcquisition']['physical_acquisition'] - $res[0]['LandAcquisition']['used'];
				if($total <= 0)
				{
					$total = 'used';
				}

				$result[] = $res[0]['LandAcquisition']['la_case_no'];
				$result[] = $total;
				$result[] = $res[0]['LandAcquisition']['physical_acquisition_unit'];


				$dta = json_encode($result);

				echo  $dta;
			}		
		$this->autoRender =  false;
	}
}
