<?php

App::uses('AppModel', 'Model');

class FilterAppModel extends AppModel {

}
