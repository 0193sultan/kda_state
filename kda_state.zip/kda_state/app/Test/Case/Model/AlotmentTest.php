<?php
App::uses('Alotment', 'Model');

/**
 * Alotment Test Case
 *
 */
class AlotmentTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.alotment',
		'app.project_name',
		'app.ploat_type',
		'app.user',
		'app.alotment_type'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Alotment = ClassRegistry::init('Alotment');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Alotment);

		parent::tearDown();
	}

}
