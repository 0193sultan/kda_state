<?php
App::uses('AlotmentTransfer', 'Model');

/**
 * AlotmentTransfer Test Case
 *
 */
class AlotmentTransferTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.alotment_transfer',
		'app.alotment',
		'app.project_name',
		'app.ploat_type',
		'app.user',
		'app.alotment_type'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->AlotmentTransfer = ClassRegistry::init('AlotmentTransfer');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->AlotmentTransfer);

		parent::tearDown();
	}

}
