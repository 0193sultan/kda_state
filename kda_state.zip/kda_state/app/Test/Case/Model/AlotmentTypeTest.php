<?php
App::uses('AlotmentType', 'Model');

/**
 * AlotmentType Test Case
 *
 */
class AlotmentTypeTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.alotment_type',
		'app.user'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->AlotmentType = ClassRegistry::init('AlotmentType');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->AlotmentType);

		parent::tearDown();
	}

}
