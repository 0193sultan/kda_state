<?php
App::uses('LandAcquisition', 'Model');

/**
 * LandAcquisition Test Case
 *
 */
class LandAcquisitionTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.land_acquisition',
		'app.user'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->LandAcquisition = ClassRegistry::init('LandAcquisition');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->LandAcquisition);

		parent::tearDown();
	}

}
