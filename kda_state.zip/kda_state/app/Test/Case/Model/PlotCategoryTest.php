<?php
App::uses('PlotCategory', 'Model');

/**
 * PlotCategory Test Case
 *
 */
class PlotCategoryTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.plot_category',
		'app.user'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->PlotCategory = ClassRegistry::init('PlotCategory');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->PlotCategory);

		parent::tearDown();
	}

}
