<?php
App::uses('Plot', 'Model');

/**
 * Plot Test Case
 *
 */
class PlotTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.plot',
		'app.project_name',
		'app.ploat_type',
		'app.user'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Plot = ClassRegistry::init('Plot');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Plot);

		parent::tearDown();
	}

}
