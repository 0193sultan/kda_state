<?php
App::uses('ProjectNameLand', 'Model');

/**
 * ProjectNameLand Test Case
 *
 */
class ProjectNameLandTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.project_name_land',
		'app.project_name',
		'app.ploat_type',
		'app.user'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->ProjectNameLand = ClassRegistry::init('ProjectNameLand');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->ProjectNameLand);

		parent::tearDown();
	}

}
