<?php
App::uses('ProjectName', 'Model');

/**
 * ProjectName Test Case
 *
 */
class ProjectNameTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.project_name',
		'app.ploat_type',
		'app.user'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->ProjectName = ClassRegistry::init('ProjectName');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->ProjectName);

		parent::tearDown();
	}

}
