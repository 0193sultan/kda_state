<?php
/**
 * AlotmentFixture
 *
 */
class AlotmentFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'project_name_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'alotment_type_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'ploat_type_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'plot_shop_billboard_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'alotment_receiver' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 100, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'father_husband_name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 100, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'address' => array('type' => 'text', 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'alotment_order_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'alotment_date' => array('type' => 'date', 'null' => false, 'default' => null),
		'per_unit_price' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'total_alotment_price' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'security_price' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'first_installment' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'installment_quantity' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'preminum_for_per_installment' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'interest_rate' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'user_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'created_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'updated_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'project_name_id' => 1,
			'alotment_type_id' => 1,
			'ploat_type_id' => 1,
			'plot_shop_billboard_no' => 1,
			'alotment_receiver' => 'Lorem ipsum dolor sit amet',
			'father_husband_name' => 'Lorem ipsum dolor sit amet',
			'address' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'alotment_order_no' => 1,
			'alotment_date' => '2017-08-24',
			'per_unit_price' => 1,
			'total_alotment_price' => 1,
			'security_price' => 1,
			'first_installment' => 1,
			'installment_quantity' => 1,
			'preminum_for_per_installment' => 1,
			'interest_rate' => 1,
			'user_id' => 1,
			'created_at' => '2017-08-24',
			'updated_at' => '2017-08-24'
		),
	);

}
