<?php
/**
 * EmployeeBonusFixture
 *
 */
class EmployeeBonusFixture extends CakeTestFixture {

/**
 * Table name
 *
 * @var string
 */
	public $table = 'employee_bonus';

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'employee_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'current_basic' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'scale_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'bonus_amount' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'percent' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'fiscal_year_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'month_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'user_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'created_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'updated_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'employee_id' => 1,
			'current_basic' => 1,
			'scale_id' => 1,
			'bonus_amount' => 1,
			'percent' => 1,
			'fiscal_year_id' => 1,
			'month_id' => 1,
			'user_id' => 1,
			'created_at' => '2017-08-14',
			'updated_at' => '2017-08-14'
		),
	);

}
