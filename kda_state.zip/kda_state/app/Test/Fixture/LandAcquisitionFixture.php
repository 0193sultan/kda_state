<?php
/**
 * LandAcquisitionFixture
 *
 */
class LandAcquisitionFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'proposal_name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 100, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'la_case_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'cs_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'sa_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'rs_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'total_land' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'physical_acquisition' => array('type' => 'float', 'null' => false, 'default' => null, 'unsigned' => false),
		'mouja' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'dagh_no' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'user_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'created_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'updated_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'proposal_name' => 'Lorem ipsum dolor sit amet',
			'la_case_no' => 1,
			'cs_no' => 1,
			'sa_no' => 1,
			'rs_no' => 1,
			'total_land' => 1,
			'physical_acquisition' => 1,
			'mouja' => 1,
			'dagh_no' => 1,
			'user_id' => 1,
			'created_at' => '2017-08-17',
			'updated_at' => '2017-08-17'
		),
	);

}
