<?php
/**
 * PlotFixture
 *
 */
class PlotFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'project_name_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'ploat_type_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'alotmentcategory_cm_trkid' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'user_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'created_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'updated_at' => array('type' => 'date', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'project_name_id' => 1,
			'ploat_type_id' => 1,
			'alotmentcategory_cm_trkid' => 1,
			'user_id' => 1,
			'created_at' => '2017-08-22',
			'updated_at' => '2017-08-22'
		),
	);

}
