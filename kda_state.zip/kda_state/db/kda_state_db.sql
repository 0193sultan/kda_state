-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2017 at 03:00 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kda_state_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `alotment_types`
--

CREATE TABLE `alotment_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alotment_types`
--

INSERT INTO `alotment_types` (`id`, `name`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Plot', 'Active', 1, '2017-08-17 14:24:54', '2017-08-17 14:25:00'),
(2, 'Shop', 'Active', 1, '2017-08-17 14:25:14', '0000-00-00 00:00:00'),
(3, 'Billboard', 'Active', 1, '2017-08-17 14:25:26', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `land_acquisitions`
--

CREATE TABLE `land_acquisitions` (
  `id` int(11) NOT NULL,
  `proposal_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `la_case_no` int(11) NOT NULL,
  `cs_no` int(11) NOT NULL,
  `sa_no` int(11) NOT NULL,
  `rs_no` int(11) NOT NULL,
  `total_land` float NOT NULL,
  `total_land_unit` enum('Achor','Katha','Shatak') NOT NULL,
  `physical_acquisition` float NOT NULL,
  `used` float NOT NULL DEFAULT '0',
  `physical_acquisition_unit` enum('Achor','Katha','Shatak') NOT NULL,
  `mouja` int(11) NOT NULL,
  `dagh_no` int(11) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `land_acquisitions`
--

INSERT INTO `land_acquisitions` (`id`, `proposal_name`, `la_case_no`, `cs_no`, `sa_no`, `rs_no`, `total_land`, `total_land_unit`, `physical_acquisition`, `used`, `physical_acquisition_unit`, `mouja`, `dagh_no`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Abdul  Hakim Property', 45645, 50000, 5544, 4545, 203534, 'Achor', 54534, 0, 'Achor', 7876, 564564, 'Active', 1, '2017-08-17', '2017-08-17');

-- --------------------------------------------------------

--
-- Table structure for table `login_tokens`
--

CREATE TABLE `login_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` char(32) NOT NULL,
  `duration` varchar(32) NOT NULL,
  `used` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `expires` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_tokens`
--

INSERT INTO `login_tokens` (`id`, `user_id`, `token`, `duration`, `used`, `created`, `expires`) VALUES
(1, 3, 'T83db4e9aaeaf41915a74e151ecb881b', 'T weeks', 0, '2016-11-16 05:01:50', '2016-11-30 05:01:50'),
(2, 1, 'T7b24139797de454b77e16481a0a5105', 'T weeks', 0, '2016-11-16 05:02:57', '2016-11-30 05:02:57'),
(3, 1, 'Te30566366d91b5ed435bae923ecfbe8', 'T weeks', 0, '2016-11-16 05:43:14', '2016-11-30 05:43:14'),
(4, 1, 'T01ab359d5aad9c873f601ca8cc206e1', 'T weeks', 1, '2016-11-16 08:20:27', '2016-11-30 08:20:27'),
(5, 1, 'T7e9e1a075007930c99d0e4fb208160e', 'T weeks', 0, '2016-11-17 08:46:26', '2016-12-01 08:46:26'),
(6, 1, 'T8104e2c8b81d7d6fef79adbaacacb4d', 'T weeks', 1, '2016-11-17 02:49:49', '2016-12-01 02:49:49'),
(7, 1, 'T4562e8f9bf2285841323aaff56463de', 'T weeks', 1, '2016-11-17 12:47:35', '2016-12-01 12:47:35'),
(8, 1, 'T4ee7ca882fa500e2a643ccb8dc294ca', 'T weeks', 1, '2016-11-20 09:42:26', '2016-12-04 09:42:26'),
(9, 1, 'Tdd5d533f64ee6f1fba4911ccb3f5ada', 'T weeks', 0, '2016-11-22 06:57:12', '2016-12-06 06:57:12'),
(10, 1, 'Td68ab3b436c578476acb0d81ba77d34', 'T weeks', 0, '2016-11-22 00:57:43', '2016-12-06 00:57:43'),
(11, 1, 'Tce0d5bd7377b2868a85cd91d4192a92', 'T weeks', 1, '2016-11-22 01:43:44', '2016-12-06 01:43:44'),
(12, 1, 'T6bc27f0052e467250b0da38c4bdffb5', 'T weeks', 1, '2016-11-22 11:11:04', '2016-12-06 11:11:04'),
(13, 1, 'T7e63c85e353d36e00f5519cfae66c21', 'T weeks', 1, '2016-11-23 03:31:01', '2016-12-07 03:31:01'),
(14, 1, 'Tb8b1bbfb4d10c5ea026ff63d5a66e5e', 'T weeks', 0, '2016-11-23 13:32:21', '2016-12-07 13:32:21'),
(15, 1, 'T4343be1803b54d919011e155079c1e3', 'T weeks', 0, '2016-11-23 09:01:10', '2016-12-07 09:01:10');

-- --------------------------------------------------------

--
-- Table structure for table `ploat_types`
--

CREATE TABLE `ploat_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ploat_types`
--

INSERT INTO `ploat_types` (`id`, `name`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Residential', 'Active', 1, '2017-08-17 14:03:43', '2017-08-17 14:07:32'),
(2, 'Commertial', 'Active', 1, '2017-08-17 14:07:51', '0000-00-00 00:00:00'),
(3, 'Indiustrial', 'Active', 1, '2017-08-17 14:08:26', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `project_names`
--

CREATE TABLE `project_names` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ploat_type_id` int(11) NOT NULL,
  `project_establish_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project_name_lands`
--

CREATE TABLE `project_name_lands` (
  `id` int(11) NOT NULL,
  `project_name_id` int(11) NOT NULL,
  `la_no` int(11) NOT NULL,
  `land_quantity` float NOT NULL,
  `land_quantity_unit` enum('Achor','Katha','Shatak') NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_group_id` bigint(20) DEFAULT NULL,
  `sales_person_id` int(11) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `active` varchar(3) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_group_id`, `sales_person_id`, `username`, `password`, `email`, `name`, `active`, `created`, `modified`) VALUES
(1, 1, 15, 'Tdmin', 'e10adc3949ba59abbe56e057f20f883e', 'Tdmin@admin.com', 'Tdmin', 'T', '2016-11-16 14:30:26', '2017-02-14 08:42:06'),
(12, 3, 16, 'Tmrul', '', NULL, NULL, 'T', '2017-02-14 08:47:14', '2017-04-23 17:20:33'),
(14, 2, 18, 'Talesmanger', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-02-14 23:23:10', '2017-02-14 23:23:10'),
(15, 3, 20, 'Thittagong', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-02-15 03:05:35', '2017-02-15 03:05:35'),
(16, 3, 21, 'Thakawest', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-02-17 10:02:40', '2017-03-01 20:27:44'),
(23, 4, 30, 'T5012', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-02-20 04:18:14', '2017-03-20 16:27:26'),
(24, 4, 32, 'Thisty', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-02-20 04:38:09', '2017-02-20 04:38:09'),
(25, 3, 33, 'Tbdullah', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-02-20 05:07:16', '2017-02-20 05:07:16'),
(82, 4, 84, 'Tshraf1', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-03-14 22:07:29', '2017-03-14 22:07:29'),
(84, 4, 86, 'T1025', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-03-15 00:24:43', '2017-03-21 11:40:41'),
(86, 4, 88, 'Test10', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-03-15 13:00:44', '2017-03-15 13:25:27'),
(90, 4, 92, 'T2143', '', NULL, NULL, 'T', '2017-03-20 12:02:00', '2017-03-20 13:24:09'),
(91, 3, 93, 'Trena', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-03-20 14:01:42', '2017-03-20 14:01:42'),
(92, 4, 94, 'Trenaso', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-03-20 14:06:18', '2017-03-20 14:06:18'),
(93, 3, 95, 'T2028', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-03-20 15:52:28', '2017-03-20 15:52:28'),
(94, 3, 96, 'Tomilla', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-01 12:00:50', '2017-04-01 12:00:50'),
(95, 4, 97, 'T1032', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-01 12:18:30', '2017-04-01 12:18:30'),
(96, 4, 98, 'T2088', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 09:35:38', '2017-04-02 09:35:38'),
(97, 3, 99, 'Togra', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 13:45:55', '2017-04-02 13:45:55'),
(98, 3, 100, 'Tajshahi', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:08:08', '2017-04-02 15:08:08'),
(99, 3, 101, 'Tangpur', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:09:02', '2017-04-02 15:09:02'),
(100, 3, 102, 'Tushtia', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:09:38', '2017-04-02 15:09:38'),
(101, 3, 103, 'Thulna', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:10:18', '2017-04-02 15:10:18'),
(102, 3, 104, 'Tarisal', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:11:02', '2017-04-02 15:11:02'),
(103, 3, 105, 'Tymensingh', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:12:23', '2017-04-02 15:12:23'),
(104, 3, 106, 'Thaka west', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:13:24', '2017-04-02 15:13:24'),
(105, 3, 107, 'Thakaeast', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:14:14', '2017-04-05 11:47:48'),
(106, 3, 108, 'Tylhet', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-02 15:14:51', '2017-04-02 15:14:51'),
(107, 4, 109, 'Tbdul Wahed', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:40:47', '2017-04-06 11:17:22'),
(108, 4, 110, 'TM Ashiqur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:41:27', '2017-04-06 11:17:50'),
(109, 4, 111, 'Tilon Biswash', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:42:48', '2017-04-06 11:18:36'),
(110, 4, 112, 'Tostafizur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:43:40', '2017-04-06 11:19:05'),
(111, 4, 113, 'Turuzzaman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:44:08', '2017-04-06 11:19:26'),
(112, 4, 114, 'Tafiqul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:44:36', '2017-04-06 11:19:50'),
(113, 4, 115, 'Taidul Islam Mondol', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:45:17', '2017-04-06 11:20:12'),
(114, 4, 116, 'TKM Saiduzzaman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:45:53', '2017-04-06 11:20:35'),
(115, 4, 117, 'Tarowar Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:46:25', '2017-04-06 11:22:52'),
(116, 4, 118, 'Tohammad Sohel', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:47:04', '2017-04-06 11:23:27'),
(117, 4, 119, 'Tirza Md. Razaul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:47:37', '2017-04-06 11:24:22'),
(118, 4, 120, 'Tahangir Alam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:48:06', '2017-04-06 11:25:06'),
(119, 4, 121, 'Tahanur Alam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:48:38', '2017-04-06 11:26:24'),
(120, 4, 122, 'Trovat Chandra Chakravarty', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:49:19', '2017-04-06 11:27:12'),
(121, 4, 123, 'Telayet Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:49:51', '2017-04-06 13:00:19'),
(122, 4, 124, 'Thariful Awwal', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:50:22', '2017-04-06 13:17:43'),
(123, 4, 125, 'Tostafizur Mostaque', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:50:51', '2017-04-06 13:18:43'),
(124, 4, 126, 'Tahedul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:51:21', '2017-04-06 13:19:30'),
(125, 4, 127, 'Tostofa Kamal Pasa', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:51:50', '2017-04-06 16:30:25'),
(126, 4, 128, 'Tabbir Ahommad Sajal', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:52:18', '2017-04-06 16:31:00'),
(127, 4, 129, 'Tojib Hasan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:53:06', '2017-04-06 16:31:53'),
(128, 4, 130, 'Tezaul Karim', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:53:51', '2017-04-06 16:32:23'),
(129, 4, 131, 'Turujjaman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:54:16', '2017-04-06 16:33:47'),
(130, 4, 132, 'Tbayedul Huq', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:55:00', '2017-04-06 16:34:21'),
(131, 4, 133, 'Taju Ahmed', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:55:27', '2017-04-06 16:34:49'),
(132, 4, 134, 'Tasum Imtiaj', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:55:50', '2017-04-06 16:35:30'),
(133, 4, 135, 'Tlamgir Kabir', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:56:36', '2017-04-06 16:36:19'),
(134, 4, 136, 'Tazlur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:57:41', '2017-04-06 16:36:49'),
(135, 4, 137, 'Tafiqul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:58:28', '2017-04-06 16:37:42'),
(136, 4, 138, 'Tzizur Rahman ', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 16:58:51', '2017-04-06 16:38:23'),
(137, 4, 139, 'Tyed Kamruzzaman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:00:18', '2017-04-06 16:38:59'),
(138, 4, 140, 'T.M.Arifur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:00:39', '2017-04-06 16:39:34'),
(139, 4, 141, 'Tohoshin', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:01:21', '2017-04-06 16:40:25'),
(140, 4, 142, 'Tamruzzaman Milon', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:01:49', '2017-04-06 16:41:53'),
(141, 4, 143, 'Tfzal Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:02:13', '2017-04-06 16:42:35'),
(142, 4, 144, 'Taiful Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:02:44', '2017-04-06 16:43:37'),
(143, 4, 145, 'Thahidul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:04:04', '2017-04-06 16:44:09'),
(144, 4, 146, 'Tbdullah Mamun', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:04:30', '2017-04-06 16:44:58'),
(145, 4, 147, 'Tishor Kumar Raha', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:04:55', '2017-04-06 16:45:32'),
(146, 4, 148, 'Tarid Uddin', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:06:35', '2017-04-06 16:46:10'),
(147, 4, 149, 'T K M Yeahya', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:07:07', '2017-04-06 16:46:39'),
(148, 4, 150, 'Tolam Easin ', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:07:36', '2017-04-06 16:47:16'),
(149, 4, 151, 'Tehedi Hassan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:08:06', '2017-04-06 16:47:46'),
(150, 4, 152, 'Tahbubur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:08:31', '2017-04-06 16:48:23'),
(151, 4, 153, 'Tizanur Rahman ', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:08:59', '2017-04-06 16:48:51'),
(152, 4, 154, 'Tishikanta Banik', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:09:23', '2017-04-06 16:49:22'),
(153, 4, 155, 'Touhedur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:10:31', '2017-04-06 16:49:52'),
(154, 4, 156, 'Tazi Fokroll Yslam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:12:07', '2017-04-06 16:50:42'),
(155, 4, 157, 'Tnupam Chandra Bhowmik', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:12:55', '2017-04-05 17:12:55'),
(156, 4, 158, 'TKM Shahid Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:13:27', '2017-04-05 17:13:27'),
(157, 4, 159, 'Thamsul Huda', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:13:51', '2017-04-05 17:13:51'),
(158, 4, 160, 'Tahirul Amin Khan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:14:30', '2017-04-05 17:14:30'),
(159, 4, 161, 'Thazzad Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:15:11', '2017-04-05 17:15:11'),
(160, 4, 162, 'Tahangir Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:15:43', '2017-04-05 17:15:43'),
(161, 4, 163, 'Thlash Uddin Masum', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:16:17', '2017-04-05 17:16:17'),
(162, 4, 164, 'Taruque Hossain Shah', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:16:48', '2017-04-05 17:16:48'),
(163, 4, 165, 'Thorif Al Mamun', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:17:17', '2017-04-05 17:17:17'),
(164, 4, 166, 'Tura Arifin Chowdhury', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:17:46', '2017-04-05 17:17:46'),
(165, 4, 167, 'Tttpal Chandra Mondol', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:18:16', '2017-04-05 17:18:16'),
(166, 4, 168, 'Tareq Mahmud', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:18:47', '2017-04-05 17:18:47'),
(167, 4, 169, 'Thalekuzzaman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:19:53', '2017-04-05 17:19:53'),
(168, 4, 170, 'Tondip Kumar Dhar', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:20:26', '2017-04-05 17:20:26'),
(169, 4, 171, 'Tbu Raihan Masud', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:21:24', '2017-04-05 17:21:24'),
(170, 4, 172, 'Tostafa Kamal', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:22:41', '2017-04-05 17:22:41'),
(171, 4, 173, 'Tahmud Reza', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:23:31', '2017-04-05 17:23:31'),
(172, 4, 174, 'Tazi Monzurul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:23:58', '2017-04-05 17:23:58'),
(173, 4, 175, 'Tamun Ar Rashid', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:24:29', '2017-04-05 17:24:29'),
(174, 4, 176, 'Tohammed Atiqure Rahman Duke', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:25:08', '2017-04-05 17:25:08'),
(175, 4, 177, 'Touhidul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:25:40', '2017-04-05 17:25:40'),
(176, 4, 178, 'TM Abdur Razzaque', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:26:05', '2017-04-05 17:26:05'),
(177, 4, 179, 'Tadequl Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:27:09', '2017-04-05 17:27:09'),
(178, 4, 180, 'Thamim Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:28:29', '2017-04-05 17:28:29'),
(179, 4, 181, 'Tohammad Tariqul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:29:01', '2017-04-05 17:29:01'),
(180, 4, 182, 'Thamsuddin', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:29:27', '2017-04-05 17:29:27'),
(181, 4, 183, 'Tozaharul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:29:57', '2017-04-05 17:29:57'),
(182, 4, 184, 'Tofazzal Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:30:24', '2017-04-05 17:30:24'),
(183, 4, 185, 'Tahangir Alam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:31:17', '2017-04-05 17:31:17'),
(184, 4, 186, 'Tofazzal Hossain Khan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:33:10', '2017-04-05 17:33:10'),
(185, 4, 187, 'Thiman Bhoumik', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:33:52', '2017-04-05 17:33:52'),
(186, 4, 188, 'Thandaker Mostakim', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:35:29', '2017-04-05 17:35:29'),
(187, 4, 189, 'Tabir Ahmed', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:36:09', '2017-04-05 17:36:09'),
(188, 4, 190, 'Turshidul Hasan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:36:43', '2017-04-05 17:36:43'),
(189, 4, 191, 'Tahidul Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:37:31', '2017-04-05 17:37:31'),
(190, 4, 192, 'Tr. Md. Rafiqul Ahsan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:37:57', '2017-04-05 17:37:57'),
(191, 4, 193, 'Tr.Md. Zakir Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:38:34', '2017-04-05 17:38:34'),
(192, 4, 194, 'Telayet Hossain Khan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:39:11', '2017-04-05 17:39:11'),
(193, 4, 195, 'Tufayel Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:39:40', '2017-04-05 17:39:40'),
(194, 4, 196, 'TM Mizanur Rahman', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:40:35', '2017-04-05 17:40:35'),
(195, 4, 197, 'Tr. Zahirul Islam Khan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:41:10', '2017-04-05 17:41:10'),
(196, 4, 198, 'Tvijit Roy Biswas', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:41:53', '2017-04-05 17:41:53'),
(197, 4, 199, 'Tk.Ahsanul Karim', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:43:23', '2017-04-05 17:43:23'),
(198, 4, 200, 'Towhid Billah', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:45:50', '2017-04-05 17:45:50'),
(199, 4, 201, 'Tazikul Ahasan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:46:29', '2017-04-05 17:46:29'),
(200, 4, 202, 'Tonoar Hossain', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:46:58', '2017-04-05 17:46:58'),
(201, 4, 203, 'Tossain Mohammad Sayem', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:47:36', '2017-04-05 17:47:36'),
(202, 4, 204, 'Tir Md. Rakibul Hasan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:48:01', '2017-04-05 17:48:01'),
(203, 4, 205, 'Toutam Chandra Mahanta', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:48:26', '2017-04-05 17:48:26'),
(204, 4, 206, 'Tasud Rana', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:48:53', '2017-04-05 17:48:53'),
(205, 4, 207, 'Tohammad Anwar Hossain Mizi', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:49:19', '2017-04-05 17:49:19'),
(206, 4, 208, 'Tbdul Hakim', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:50:11', '2017-04-05 17:50:11'),
(207, 4, 209, 'Trokash Saha', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:51:52', '2017-04-05 17:51:52'),
(208, 4, 210, 'Thaymol Kumar Singha', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:52:19', '2017-04-05 17:52:19'),
(209, 4, 211, 'Telim Reza', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:52:45', '2017-04-05 17:52:45'),
(210, 4, 212, 'Tikash Chandra Bardhan', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:53:58', '2017-04-05 17:53:58'),
(211, 4, 213, 'T.M. Sheik Saadi', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:54:33', '2017-04-05 17:54:33'),
(212, 4, 214, 'Triful Islam', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-05 17:54:58', '2017-04-05 17:54:58'),
(213, 4, 215, 'Tumonuzzaman', '', NULL, NULL, 'T', '2017-04-05 17:55:28', '2017-04-05 23:10:06'),
(214, 4, 216, 'T0012', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-06 11:17:02', '2017-04-06 11:17:02'),
(215, 4, 10097, 'Trenaso2', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-04-16 12:39:12', '2017-04-16 12:39:12'),
(218, 4, 10100, 'Tntora', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-05-06 20:24:20', '2017-05-06 20:24:20'),
(219, 4, 10101, 'Trenaso3', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-05-14 20:22:34', '2017-05-14 20:22:34'),
(1219, 4, 20101, 'Taser', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-05-15 14:12:27', '2017-05-27 20:00:24'),
(2219, 6, 30101, 'Trenaspo', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-05-22 13:08:37', '2017-05-22 13:08:37'),
(2220, 6, 30102, 'Trenaspo2', 'T10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'T', '2017-05-22 13:32:39', '2017-05-29 13:10:01');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `alias_name` varchar(100) DEFAULT NULL,
  `allowregistration` int(11) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `alias_name`, `allowregistration`, `created`, `modified`) VALUES
(1, 'TasterAdmin', 'Taster admin', 1, '2016-11-16 14:30:26', '2017-02-26 09:49:02'),
(2, 'Tdmin', 'Tdmin', 1, '2016-11-16 14:30:26', '2016-11-16 14:30:26'),
(3, 'TSO', 'TSO Admin', 1, '2017-02-14 07:54:57', '2017-02-14 07:54:57'),
(4, 'TO', 'TO', 1, '2017-02-14 08:47:58', '2017-02-14 08:47:58'),
(5, 'Togistic', 'Trea Logistics Officer', 1, '2017-03-20 05:44:08', '2017-03-20 05:44:08'),
(6, 'TPO', 'TPO', 1, '2017-05-22 03:06:20', '2017-05-22 03:06:20');

-- --------------------------------------------------------

--
-- Table structure for table `user_group_permissions`
--

CREATE TABLE `user_group_permissions` (
  `id` bigint(20) NOT NULL,
  `user_group_id` bigint(20) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `action` varchar(100) NOT NULL,
  `allowed` tinyint(3) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_group_permissions`
--

INSERT INTO `user_group_permissions` (`id`, `user_group_id`, `controller`, `action`, `allowed`) VALUES
(1, 1, 'PloatTypes', 'admin_index', 1),
(2, 1, 'PloatTypes', 'admin_add', 1),
(3, 1, 'PloatTypes', 'admin_edit', 1),
(4, 1, 'PloatTypes', 'admin_view', 1),
(5, 1, 'PloatTypes', 'admin_delete', 1),
(6, 1, 'AlotmentTypes', 'admin_index', 1),
(7, 1, 'AlotmentTypes', 'admin_add', 1),
(8, 1, 'AlotmentTypes', 'admin_edit', 1),
(9, 1, 'AlotmentTypes', 'admin_view', 1),
(10, 1, 'AlotmentTypes', 'admin_delete', 1),
(11, 1, 'LandAcquisitions', 'admin_index', 1),
(12, 1, 'LandAcquisitions', 'admin_add', 1),
(13, 1, 'LandAcquisitions', 'admin_edit', 1),
(14, 1, 'LandAcquisitions', 'admin_view', 1),
(15, 1, 'LandAcquisitions', 'admin_delete', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alotment_types`
--
ALTER TABLE `alotment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `land_acquisitions`
--
ALTER TABLE `land_acquisitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_tokens`
--
ALTER TABLE `login_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ploat_types`
--
ALTER TABLE `ploat_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_names`
--
ALTER TABLE `project_names`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_name_lands`
--
ALTER TABLE `project_name_lands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mail` (`email`),
  ADD KEY `user` (`username`),
  ADD KEY `users_fkindex1` (`user_group_id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_group_permissions`
--
ALTER TABLE `user_group_permissions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alotment_types`
--
ALTER TABLE `alotment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `land_acquisitions`
--
ALTER TABLE `land_acquisitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `login_tokens`
--
ALTER TABLE `login_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `ploat_types`
--
ALTER TABLE `ploat_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `project_names`
--
ALTER TABLE `project_names`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `project_name_lands`
--
ALTER TABLE `project_name_lands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2221;
--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_group_permissions`
--
ALTER TABLE `user_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
